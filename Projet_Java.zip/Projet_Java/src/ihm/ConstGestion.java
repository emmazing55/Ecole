package ihm;

public interface ConstGestion {

	
	final static int WINDOW_WIDTH  = 800 ;
	final static int WINDOW_HEIGHT = 800 ;
	
	final static int BUTTON_WIDTH  = 110 ;
	final static int BUTTON_HEIGHT = 23 ;
}
