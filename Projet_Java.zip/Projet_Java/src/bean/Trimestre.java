package bean;

import java.util.Date;

/**
 *attributs prives
 * @author emmaz
 */
public class Trimestre {
	

	private Integer id;
	private Integer numero;
	private Date dateDebut;
	private Date dateFin;
	
    /**
     *constrcuteur par defaut
     */
    public Trimestre() {
	}
	
    /**
     *constrcuteur surcharge
     * @param numero
     * @param dateDebut
     * @param dateFin
     */
    public Trimestre(Integer numero, Date dateDebut, Date dateFin) {
		this.numero = numero;
		this.dateDebut = dateDebut;
		this.dateFin = dateFin;
	}

    /**
     *constrcuteur surcharge
     * @param id
     * @param numero
     * @param dateDebut
     * @param dateFin
     */
    public Trimestre(Integer id, Integer numero, Date dateDebut, Date dateFin) {
		this(numero,dateDebut ,dateFin);
		this.id = id;
	}

	/**
         * getter id
	 * @return the id
	 */
	public Integer getId() {
		return id;
	}

	/**
         * setter id
	 * @param id the id to set
	 */
	public void setId(Integer id) {
		this.id = id;
	}

	/**
         * getter numero
	 * @return the numero
	 */
	public Integer getNumero() {
		return numero;
	}

	/**
         * setter numero
	 * @param numero the numero to set
	 */
	public void setNumero(Integer numero) {
		this.numero = numero;
	}

	/**
         * getter date debut
	 * @return the dateDebut
	 */
	public Date getDateDebut() {
		return dateDebut;
	}

	/**
         * setter date debut
	 * @param dateDebut the dateDebut to set
	 */
	public void setDateDebut(Date dateDebut) {
		this.dateDebut = dateDebut;
	}

	/**
         * getter datefin
	 * @return the dateFin
	 */
	public Date getDateFin() {
		return dateFin;
	}

	/**
         * setter date fin
	 * @param dateFin the dateFin to set
	 */
	public void setDateFin(Date dateFin) {
		this.dateFin = dateFin;
	}
	
	
	
	

}
