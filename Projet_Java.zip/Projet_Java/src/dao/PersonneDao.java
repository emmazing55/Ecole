package dao;


import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import bean.Personne;
import java.sql.PreparedStatement;

/**
 *methode personne 
 * @author emmaz
 */
public class PersonneDao  extends GestionDao<Personne>{
	
    /**
     *methode find 
     * @param conn
     * @param bean
     * @return
     */
    @Override
	public Personne find(Connection conn, Personne bean) {

		ResultSet result = null;
		Statement stmt = null;
		Personne personneFound = null;
		String requete = "SELECT id, nom, prenom, type FROM personne WHERE id  = "  + bean.getId() ;
		try {
			stmt = conn.createStatement();
			result = stmt.executeQuery(requete);
			if (result!=null && result.next())
			{
				personneFound = new Personne(result.getInt(1),result.getString(2),result.getString(3),result.getString(4));
			}

		} catch (SQLException e) {
			e.printStackTrace();
		
		}
		return personneFound;
	}	

    /**
     *methode inserer 
     * @param conn
     * @param bean
     */
    @Override
	public void insert(Connection conn, Personne bean) {
		
		  Statement stmt = null;
		try
                {
                  
                String requete = "INSERT INTO personne (nom, prenom, type) values (?,?,?)";
                PreparedStatement statement = conn.prepareStatement(requete);
                statement.setObject(1, bean.getNom());
                statement.setObject(2, bean.getPrenom());
                statement.setObject(3, bean.getType());
//                ;
                System.out.println(requete);
                statement.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} 

		
		
	}

    /**
     *methde delete
     * @param conn
     * @param bean
     */
    @Override
	public void delete(Connection conn, Personne bean) {
		
		Statement stmt = null;
                try
                {
                  
                String requete = "DELETE FROM personne WHERE id = " + bean.getId();
                PreparedStatement statement = conn.prepareStatement(requete);
                
                System.out.println(requete);
                statement.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} 
		


	}

    /**
     *methode update
     * @param conn
     * @param bean
     */
    @Override
	public void update(Connection conn, Personne bean) {
		
		Statement stmt = null;
               try 
               {
		String requete = "UPDATE personne SET nom = " + bean.getNom() + 
				" ,prenom = " + bean.getPrenom() +
			        " ,type = " + bean.getType() +
				"  WHERE id = " + bean.getId();
                  PreparedStatement statement = conn.prepareStatement(requete);
		 System.out.println(requete);
                statement.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} 
			
	
	}

    /**
     *methode find all
     * @param conn
     * @return
     */
    @Override
	public ArrayList<Personne> findAll(Connection conn) {

		Statement stmt = null;
		ResultSet result = null;
		ArrayList<Personne> listeResultat = new ArrayList<Personne>();
		
		String requete =  " SELECT * FROM personne; " ;
		
		try {
			stmt = conn.prepareStatement(requete);
			result = stmt.executeQuery(requete);
			
			while(result.next()) {
				Personne personne = new Personne();   
				personne = new Personne(result.getInt(1),result.getString(2),result.getString(3),result.getString(4));
				listeResultat.add(personne);
			} 
			
		} catch (SQLException e) {
			e.printStackTrace();
		} 
	
		return listeResultat;
	}	
}
