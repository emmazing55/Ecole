package dao;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import bean.Classe;

/**
 * modele dao 
 * @author emmaz
 */
public class ClasseDao extends GestionDao<Classe> {

    /**
     *methode find 
     * @param conn
     * @param bean
     * @return
     */
    @Override
	public Classe find(Connection conn, Classe bean) {
		
		return null;
	}

    /**
     *methode insert
     * @param conn
     * @param bean
     */
    @Override
	public void insert(Connection conn, Classe bean) {
		
	}

    /**
     *methode delete
     * @param conn
     * @param bean
     */
    @Override
	public void delete(Connection conn, Classe bean) {
		
		Statement stmt = null;
		String requete = "delete classe " + 
				"  where id = " + bean.getId()+ ";";
		try {
			stmt = conn.createStatement();
			stmt.executeUpdate(requete);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}

    /**
     *methode update
     * @param conn
     * @param bean
     */
    @Override
	public void update(Connection conn, Classe bean) {
		Statement stmt = null;
		String requete = "update classe set nom = " + bean.getNom() + 
				"  where id = " + bean.getId()+ ";";
		try {
			stmt = conn.createStatement();
			stmt.executeUpdate(requete);
		} catch (SQLException e) {
			e.printStackTrace();
		} 
        }

    /**
     *methode findall
     * @param conn
     * @return
     */
    @Override
	public ArrayList<Classe> findAll(Connection conn) {
		
		return null;
	}



}
