package bean;

/**
 * attributs prives
 *
 * @author emmaz
 */
public class Classe {
	
	private Integer id;
	private String nom;
	private Ecole ecole;
	private Niveau niveau;
	private AnneeScolaire anneeScolaire;
	
    /**
     *constrcuteur par defaut
     */
    public Classe() {
	}
	
    /**
     *constructeur surcharge
     * @param nom
     * @param ecole
     * @param niveau
     * @param anneeScolaire
     */
    public Classe( String nom,Ecole ecole, Niveau niveau, AnneeScolaire anneeScolaire) {
		this.nom = nom;
		this.ecole = ecole;
		this.niveau = niveau;
		this.anneeScolaire = anneeScolaire;
	}

    /**
     *constructeur surcharge
     * @param id
     * @param nom
     * @param ecole
     * @param niveau
     * @param anneeScolaire
     */
    public Classe(Integer id, String nom ,Ecole ecole, Niveau niveau, AnneeScolaire anneeScolaire) {
		this(nom,ecole,niveau,anneeScolaire);
		this.id = id;
	}

	/**
         * getter id
	 * @return the id
	 */
	public Integer getId() {
		return id;
	}
	/**
         * setter id
	 * @param id the id to set
	 */
	public void setId(Integer id) {
		this.id = id;
	}
	/**
         * getter ecole
	 * @return the ecole
	 */
	public Ecole getEcole() {
		if (ecole == null)
		{	
			ecole = new Ecole();
		}	
		return ecole;
	}
	/**
         * setter ecole
	 * @param ecole the ecole to set
	 */
	public void setEcole(Ecole ecole) {
		this.ecole = ecole;
	}
	/**
         * getter niveau
	 * @return the niveau
	 */
	public Niveau getNiveau() {
		if (niveau == null)
		{	
			niveau = new Niveau();
		}	
		return niveau;
	}
	/**
         * setter  niveau
	 * @param niveau the niveau to set
	 */
	public void setNiveau(Niveau niveau) {
		this.niveau = niveau;
	}
	/**
         * getter anneescolaire
	 * @return the anneeScolaire
	 */
	public AnneeScolaire getAnneeScolaire() {
		
		if (anneeScolaire == null)
		{	
			anneeScolaire = new AnneeScolaire();
		}	
		return anneeScolaire;
	}
	/**
         * setter annee scolaire
	 * @param anneeScolaire the anneeScolaire to set
	 */
	public void setAnneeScolaire(AnneeScolaire anneeScolaire) {
		this.anneeScolaire = anneeScolaire;
	}

	/**
         * getter nom
	 * @return the nom
	 */
	public String getNom() {
		return nom;
	}

	/**
         * setter nom
	 * @param nom the nom to set
	 */
	public void setNom(String nom) {
		this.nom = nom;
	}
	
   
}
