package bean;

/**
 *attributs en prives
 * @author emmaz
 */
public class Evaluation {
	
	
	private Integer id;;
	private Integer note;
	private String appreciation;
	
    /**
     *constructeur par defaut
     */
    public Evaluation() {
	}

    /**
     * constructeur surcharge
     *
     * @param detail
     * @param note
     * @param appreciation
     */
    public Evaluation( Integer note, String appreciation) {
	
		this.note = note;
		this.appreciation = appreciation;
	}

    /**
     *constructeur surcharge
     * @param id
     * @param detail
     * @param note
     * @param appreciation
     */
    public Evaluation(Integer id, Integer note, String appreciation) {
		this(note,appreciation);
		this.id = id;
	}


	/**
         * getter id
	 * @return the id
	 */
	public Integer getId() {
		return id;
	}


	/**
         * setter id
	 * @param id the id to set
	 */
	public void setId(Integer id) {
		this.id = id;
	}


	

	

	/**
         * getter note
	 * @return the note
	 */
	public Integer getNote() {
		return note;
	}


	/**
         * setter  note
	 * @param note the note to set
	 */
	public void setNote(Integer note) {
		this.note = note;
	}


	/**
         * getter appreciation
	 * @return the appreciation
	 */
	public String getAppreciation() {
		return appreciation;
	}


	/**
         * setter apprecation
	 * @param appreciation the appreciation to set
	 */
	public void setAppreciation(String appreciation) {
		this.appreciation = appreciation;
	}
	
	
	

}
