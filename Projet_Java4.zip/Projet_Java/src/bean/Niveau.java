package bean;

/**
 *attributs prives
 * @author emmaz
 */
public class Niveau {
	
	private Integer id;
	private String nom;
	
    /**
     *constructeur par defaut
     */
    public Niveau() {
	}

    /**
     *
     * constructeur surcharge
     * @param nom
     */
    public Niveau(String nom) {
		this.nom = nom;
	}

    /**
     *constructeur surcharge
     * @param id
     * @param nom
     */
    public Niveau(Integer id, String nom) {
		this.id = id;
		this.nom = nom;
	}


	/**
         * getter id
	 * @return the id
	 */
	public Integer getId() {
		return id;
	}


	/**
         * setter id
	 * @param id the id to set
	 */
	public void setId(Integer id) {
		this.id = id;
	}


	/**
         * getter nom
	 * @return the nom
	 */
	public String getNom() {
		return nom;
	}


	/**
         * setter nom
	 * @param nom the nom to set
	 */
	public void setNom(String nom) {
		this.nom = nom;
	}
	

	
	

}
