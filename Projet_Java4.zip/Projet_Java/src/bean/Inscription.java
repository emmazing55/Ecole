package bean;

/**
 *attributs prives
 * @author emmaz
 */
public class Inscription {
	
	
	private Integer id;
	private Classe classe;
	private Personne etudiant;

    /**
     *constructeur par defaut
     */
    public Inscription()
	{
	}
	
    /**
     * constrcuteur surcharge
     * @param classe
     * @param etudiant
     */
    public Inscription(Classe classe, Personne etudiant) {
		this.classe = classe;
		this.etudiant = etudiant;
	}
	
    /**
     *constrcuteur surcharge
     * @param id
     * @param classe
     * @param etudiant
     */
    public Inscription(Integer id, Classe classe, Personne etudiant) {
		this(classe ,etudiant);
		this.id = id;
	}

	
	/**
         * getter id
	 * @return the id
	 */
	public Integer getId() {
		return id;
	}
	/**
         * setter id
	 * @param id the id to set
	 */
	public void setId(Integer id) {
		this.id = id;
	}
	/**
         * getter classe
	 * @return the classe
	 */
	public Classe getClasse() {
		
		
		if( classe== null)
		{
			classe = new Classe();
		}
		
		return classe;
	}
	/**
         * setter classe
	 * @param classe the classe to set
	 */
	public void setClasse(Classe classe) {
		this.classe = classe;
	}
	/**
         * getter etudiant
	 * @return the etudiant
	 */
	public Personne getEtudiant() {
		
		if( etudiant== null)
		{
			etudiant = new Personne();
		}
		return etudiant;
	}
	/**
         * setter etudiant
	 * @param etudiant the etudiant to set
	 */
	public void setEtudiant(Personne etudiant) {
		this.etudiant = etudiant;
	}
	
}
