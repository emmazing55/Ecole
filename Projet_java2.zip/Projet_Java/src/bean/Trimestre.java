package bean;

import java.util.Date;

public class Trimestre {
	

	private Integer id;
	private Integer numero;
	private Date dateDebut;
	private Date dateFin;
	
	public Trimestre() {
	}
	
	public Trimestre(Integer numero, Date dateDebut, Date dateFin) {
		this.numero = numero;
		this.dateDebut = dateDebut;
		this.dateFin = dateFin;
	}

	public Trimestre(Integer id, Integer numero, Date dateDebut, Date dateFin) {
		this(numero,dateDebut ,dateFin);
		this.id = id;
	}

	/**
	 * @return the id
	 */
	public Integer getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Integer id) {
		this.id = id;
	}

	/**
	 * @return the numero
	 */
	public Integer getNumero() {
		return numero;
	}

	/**
	 * @param numero the numero to set
	 */
	public void setNumero(Integer numero) {
		this.numero = numero;
	}

	/**
	 * @return the dateDebut
	 */
	public Date getDateDebut() {
		return dateDebut;
	}

	/**
	 * @param dateDebut the dateDebut to set
	 */
	public void setDateDebut(Date dateDebut) {
		this.dateDebut = dateDebut;
	}

	/**
	 * @return the dateFin
	 */
	public Date getDateFin() {
		return dateFin;
	}

	/**
	 * @param dateFin the dateFin to set
	 */
	public void setDateFin(Date dateFin) {
		this.dateFin = dateFin;
	}
	
	
	
	

}
