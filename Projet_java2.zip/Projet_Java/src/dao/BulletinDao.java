/**
 * 
 */
package dao;

import java.sql.Connection;
import java.util.ArrayList;

import bean.Bulletin;

/**
 * @author 
 *
 */
public class BulletinDao extends GestionDao<Bulletin>{

	@Override
	public Bulletin find(Connection conn, Bulletin bean) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void insert(Connection conn, Bulletin bean) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void delete(Connection conn, Bulletin bean) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void update(Connection conn, Bulletin bean) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public ArrayList<Bulletin> findAll(Connection conn) {
		// TODO Auto-generated method stub
		return null;
	}



}
