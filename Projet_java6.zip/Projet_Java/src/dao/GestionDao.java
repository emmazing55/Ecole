package dao;

import java.sql.Connection;
import java.util.ArrayList;

/**
 *comparable
 * @author emmaz
 * @param <T>
 */
public abstract class  GestionDao <T> {
	
    /**
     *find
     * @param conn
     * @param bean
     * @return
     */
    public abstract T find   (Connection conn, T bean);
	
    /**
     *insert
     * @param conn
     * @param bean
     */
    public abstract void insert (Connection conn, T bean);
	
    /**
     *delete
     * @param conn
     * @param bean
     */
    public abstract void delete (Connection conn, T bean); 
	
    /**
     *update
     * @param conn
     * @param bean
     */
    public abstract void update (Connection conn, T bean);
	
    /**
     *find all
     * @param conn
     * @return
     */
    public abstract ArrayList<T> findAll (Connection conn);
	
}
