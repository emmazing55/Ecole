package dao;

import java.sql.Connection;
import java.sql.DriverManager;

/**
 *classe connexion
 * @author emmaz
 */
public abstract class Connexion {

     static Connection conn = null;

    /**
     *create connection
     * @param name
     * @param user
     * @param password
     * @return
     * @throws Exception
     */
    public static Connection createConnection (String name, String user, String password ) throws Exception {

String urlDatabase = "jdbc:mysql://localhost/" + name;    
       String driver = "com.mysql.jdbc.Driver";

        Class.forName(driver);
        conn = DriverManager.getConnection(urlDatabase, user, password);
        return conn;
    }
    
    /**
     *getter connection
     * @return
     */
    public static Connection getConnection ()
    {
    	return conn;
    }
}

