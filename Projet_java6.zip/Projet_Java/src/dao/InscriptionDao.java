package dao;


import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import bean.Inscription;
import java.sql.PreparedStatement;

/**
 *inscription 
 * @author emmaz
 */
public class InscriptionDao extends GestionDao<Inscription> {

    /**
     *methode find
     * @param conn
     * @param bean
     * @return
     */
    @Override
	public Inscription find(Connection conn, Inscription bean) {
			ResultSet result = null;
			Statement stmt = null;
			Inscription inscriptionFound = new  Inscription();
			
			String requete =  " SELECT ID,  ID_CLASSE, C.NOM NOM_CLASSE,   "
					+ " ID_NIVEAU, N.NOM NOM_NIVEAU,  "
					+ " ID_ANNEE, DEBUT, FIN,  "
					+ " ID_PERSONNE, P.NOM NOM_PERSONNE, P.PRENOM,  "
					+ " FROM Inscription I, Classe C, Personne P, Ecole E, AnneeScolaire A, Niveau N "
					+" WHERE I.ID_CLASSE = C.ID "
					+ " AND I.ID_PERSONNE = P.ID " 
					+ " AND C.ID_ECOLE = E.ID "
					+ " AND C.ID_NIVEAU = N.ID "
					+ " AND C.ID_ANNEE = A.ID "
					+ " WHERE id  = "  + bean.getId() + " ;"  ;
			
			try {
				stmt = conn.createStatement();
				result = stmt.executeQuery(requete);
				
			} catch (SQLException e) {
				e.printStackTrace();
			
			}
			return inscriptionFound;
	}	

    /**
     *methode insert
     * @param conn
     * @param bean
     */
    @Override
	public void insert(Connection conn, Inscription bean) {
		Statement stmt = null;
                try {
		String requete = "INSERT INTO inscription (id_classe, id_personne) values (" + bean.getClasse().getId() + "," + bean.getEtudiant().getId() +");" ;
		  PreparedStatement statement = conn.prepareStatement(requete);
                  System.out.println(requete);
                statement.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} 
		
		
	}

    /**
     *methode delete
     * @param conn
     * @param bean
     */
    @Override
	public void delete(Connection conn, Inscription bean) {
		Statement stmt = null;
                try {
		String requete = "DELETE inscription WHERE id = " + bean.getId() +" ;";
		
			 PreparedStatement statement = conn.prepareStatement(requete);
                  System.out.println(requete);
                statement.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} 
		
		
	}

    /**
     * methode update
     *
     * @param conn
     * @param bean
     */
    @Override
	public void update(Connection conn, Inscription bean) {
		Statement stmt = null;
                try {
		String requete = "UPDATE inscription SET id_classe = " + bean.getClasse().getId() + 
				",  id_personne = " + bean.getEtudiant().getId() +
				"  WHERE id = " + bean.getId()+ ";";
		 PreparedStatement statement = conn.prepareStatement(requete);
                  System.out.println(requete);
                statement.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} 
		
		
		
	}

    /**
     *methode find all
     * @param conn
     * @return
     */
    @Override
	public ArrayList<Inscription> findAll(Connection conn) {
		Statement stmt = null;
		ResultSet result = null;
		ArrayList<Inscription> listeResultat = new ArrayList<Inscription>();
		
		String requete =  " SELECT id  id_classe, C.nom nom_classe,   "
				+ " id_niveaux, N.nom nom_niveau,  "
				+ " id_annee,debut,fin,  "
				+ " id_personne, P.nom nom_personne, p.prenom,  "
				+ " from Inscription I, Classe C, Personne P, Ecole E, AnneeScolaire A, Niveau N "
				+ " WHERE I.ID_CLASSE = C.ID "
				+ " AND I.ID_PERSONNE = P.ID " 
				+ " AND C.ID_ECOLE = E.ID "
				+ " AND C.ID_NIVEAU = N.ID "
				+ " AND C.ID_ANNEE = A.ID "
				+ " ; " ;
		
		try {
			stmt = conn.prepareStatement(requete);
			result = stmt.executeQuery(requete);
			
			
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		
		return listeResultat;
	}	

}
