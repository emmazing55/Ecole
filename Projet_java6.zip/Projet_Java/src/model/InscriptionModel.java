package model;

import java.util.List;

import javax.swing.table.AbstractTableModel;

import bean.Inscription;

/**
 *insertion tableau
 * @author emmaz
 */
public class InscriptionModel extends AbstractTableModel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4081299893555591675L;

	private List<Inscription> inscriptions;
	
    /**
     *
     * @param inscriptions
     */
    public InscriptionModel (List<Inscription> inscriptions)
	{
		this.inscriptions=inscriptions;
	}
	
	private final String[] entetes = { "Identifiant", "Nom Classe", "Niveau" ,"Date debut","Date fin", "Nom", "Prenom"};
	
    /**
     *getter
     * @return
     */
    @Override
	public int getColumnCount() {
		return entetes.length;
	}

    /**
     *setter
     * @return
     */
    @Override
	public int getRowCount() {
		return inscriptions.size();
	}

    /**
     *getvalueA
     * @param rowIndex
     * @param columnIndex
     * @return
     */
    @Override
	public Object getValueAt(int rowIndex, int columnIndex) {
		switch (columnIndex) {
		case 0:
			// identifiant
			return inscriptions.get(rowIndex).getId();

		case 1:
			//  Classe
			return inscriptions.get(rowIndex).getClasse().getEcole();

		case 2:
			// Niveau
			return inscriptions.get(rowIndex).getClasse().getNiveau().getNom();

		case 3:
			// Annee scolaire
			return inscriptions.get(rowIndex).getClasse().getAnneeScolaire().getDateDebut();
		
		case 4:
			// Annee scolaire
			return inscriptions.get(rowIndex).getClasse().getAnneeScolaire().getDateFin();
			
		case 5:
			// Nom
			return inscriptions.get(rowIndex).getEtudiant().getNom();
			
		case 6:
			// prenom
			return inscriptions.get(rowIndex).getEtudiant().getPrenom();
				
		default:
			throw new IllegalArgumentException();
		}
	}
	
    /**
     *getter column index
     * @param columnIndex
     * @return
     */
    @Override
	public String getColumnName(int columnIndex) {
		return entetes[columnIndex];
	}
	
    /**
     *getter inscription
     * @return
     */
    public List<Inscription> getInscriptions() {
		return inscriptions;
	}
}
