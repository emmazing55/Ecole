package bean;

/**
 *attributs prives
 * @author emmaz
 */
public class Enseignement {
	
	
	private Integer id;
	private Classe classe;
	
	private Personne enseignant;
	
    /**
     *constructeur par defaut
     */
    public Enseignement() {
	}

    /**
     * constructeur surcharge
     *
     * @param classe
     * @param discipline
     * @param enseignant
     */
    public Enseignement(Classe classe, Personne enseignant) {
		this.classe = classe;
		
		this.enseignant = enseignant;
	}

    /**
     *constructeur surcharge
     * @param id
     * @param classe
     * @param discipline
     * @param enseignant
     */
    public Enseignement(Integer id, Classe classe,  Personne enseignant) {
		this(classe,enseignant);
		this.id = id;
	}

	
	/**
         * getter id
	 * @return the id
	 */
	public Integer getId() {
		return id;
	}

	/**
         * setter id
	 * @param id the id to set
	 */
	public void setId(Integer id) {
		this.id = id;
	}

	/**
         * getter classe
	 * @return the classe
	 */
	public Classe getClasse() {
		return classe;
	}

	/**
         * setter classe
	 * @param classe the classe to set
	 */
	public void setClasse(Classe classe) {
		this.classe = classe;
	}

	

	
	/**
         * getter enseignant
	 * @return the enseignant
	 */
	public Personne getEnseignant() {
		return enseignant;
	}

	/**
         * setter enseignant
	 * @param enseignant the enseignant to set
	 */
	public void setEnseignant(Personne enseignant) {
		this.enseignant = enseignant;
	}
	
	
	
	
	

}
