package bean;

/**
 *attributs prives
 * @author emmaz
 */
public class Bulletin {
	
	
	private Integer id;
	private Trimestre trimestre;
	private Inscription inscription;
	private String appreciation;
	
    /**
     *constructeur par defaut
     */
    public Bulletin() {

	}
	
    /**
     *constructeur surchargé
     * @param trimestre
     * @param inscription
     * @param appreciation
     */
    public Bulletin(Trimestre trimestre, Inscription inscription, String appreciation) {
		this.trimestre = trimestre;
		this.inscription = inscription;
		this.appreciation = appreciation;
	}
	
    /**
     *constructeur surcharge
     * @param id
     * @param trimestre
     * @param inscription
     * @param appreciation
     */
    public Bulletin(Integer id, Trimestre trimestre, Inscription inscription, String appreciation) {
	    this(trimestre,inscription,appreciation);
		this.id = id;
	}
	/**
         * getter id
	 * @return the id
	 */
	public Integer getId() {
		return id;
	}
	/**
         * setter id 
	 * @param id the id to set
	 */
	public void setId(Integer id) {
		this.id = id;
	}
	/**
         * getter trimestre
	 * @return the trimestre
	 */
	public Trimestre getTrimestre() {
		return trimestre;
	}
	/**
         * setter trimestre
	 * @param trimestre the trimestre to set
	 */
	public void setTrimestre(Trimestre trimestre) {
		this.trimestre = trimestre;
	}
	/**
         * getter inscription
	 * @return the inscription
	 */
	public Inscription getInscription() {
		return inscription;
	}
	/**
         * setter inscription
	 * @param inscription the inscription to set
	 */
	public void setInscription(Inscription inscription) {
		this.inscription = inscription;
	}
	/**
         * getter appreciatio 
	 * @return the appreciation
	 */
	public String getAppreciation() {
		return appreciation;
	}
	/**
         * setter appreciation
	 * @param appreciation the appreciation to set
	 */
	public void setAppreciation(String appreciation) {
		this.appreciation = appreciation;
	}

}
